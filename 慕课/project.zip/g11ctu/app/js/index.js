import 'babel-polyfill';
import Lottery from './lottery';
